let u;
let y;
let uspeed;
let yspeed;
let txt = "TAKE A BREAK!";

let a;
let c;
let aspeed;
let cspeed;
let txt2 = "drink some water!";


let r, g, b; // Farbvariablen

let directionX=1;
let directionY=1;

let directionA=1;
let directionC=1;

let size1 = 70;
let size2 = 30;

function setup() {
  createCanvas(windowWidth, windowHeight);
  textSize(55);
  textAlign(LEFT, TOP);
  

  u = random(width); // Zufällige Position zwischen 0 und der Canvas-Breite
  y = random(height);
  uspeed = 2;
  yspeed = 2;

  a = random(width); // Zufällige Position zwischen 0 und der Canvas-Breite
  c = random(height);
  aspeed = 2;
  cspeed = 2;

  //Startfarbe
  r = 0;
  g = 0;
  b = 255;
}

function draw() {
  //clear();
  textSize(size1); // Größe für Text 1 setzen
  fill(r, g, b);
  text(txt, u, y); //der text steht an den x und y positionen

  textSize(size2); // Größe für Text 2 setzen
  fill(r, g, b);
  text(txt2, a, c); //der text steht an den x und y positionen
  
  stroke(255);
  strokeWeight(2);

  // Textposition aktualisieren Der x-Wert wird um den Wert von xspeed erhöht. 
  // Dadurch bewegt sich der Text nach rechts (oder nach links, wenn xspeed negativ ist).
  u += uspeed;
  y += yspeed;

  a += aspeed;
  c += cspeed;

  // Textbreite und -höhe berücksichtigen
  //Berechnet die Breite des Textes. Du brauchst diesen Wert, um zu wissen, 
  // wann der Text den rechten Rand des Canvas erreicht.
  //Berechnet die Höhe des Textes. Dies berücksichtigt den oberen (Ascent) 
  // und unteren (Descent) Teil des Textes, sodass du auch erkennen kannst, 
  // wann der Text den oberen oder unteren Rand erreicht.
  let tw = textWidth(txt);
  let th = textAscent() + textDescent();

  // Randkollision prüfen und Farbe ändern
  //Wenn der Text den rechten Rand erreicht 
  // (wenn die aktuelle x-Position plus die 
  // Textbreite größer oder gleich der Canvas-Breite ist) 
  // oder den linken Rand überschreitet (wenn x <= 0), wird 
  // die Richtung der Bewegung in der X-Richtung umgekehrt (xspeed = -xspeed).
  if (u + tw >= width && directionX==1) {
    uspeed = -uspeed;
    changeColor();
    directionX=0;
  }
  if (u <0 && directionX==0) {
    uspeed = -uspeed;
    changeColor();
    directionX=1;
  }
  

  if (y + th >= height && directionY==1) {
    yspeed = -yspeed;
    changeColor();
    directionY=0;
  }
  if (y < 0 && directionY==0) {
    yspeed = -yspeed;
    changeColor();
    directionY=1;
  }





  if (a + tw >= width && directionA==1) {
    aspeed = -aspeed;
    changeColor();
    directionA=0;
  }
  if (a <0 && directionA==0) {
    aspeed = -aspeed;
    changeColor();
    directionA=1;
  }
  

  if (c + th >= height && directionC==1) {
    cspeed = -cspeed;
    changeColor();
    directionC=0;
  }
  if (c < 0 && directionC==0) {
    cspeed = -cspeed;
    changeColor();
    directionC=1;
  }
}

// Funktion zum Farbwechsel
function changeColor() {
 r = random(0,255);
 g = 0;
  b = random(200,255);
}



